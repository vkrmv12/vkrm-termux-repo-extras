#!/data/data/com.vkrm/files/usr/bin/sh

echo "$@"
