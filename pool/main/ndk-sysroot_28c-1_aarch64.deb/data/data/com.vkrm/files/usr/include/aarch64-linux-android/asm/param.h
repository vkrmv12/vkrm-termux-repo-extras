/*
 * This file is auto-generated. Modifications will be lost.
 *
 * See https://android.googlesource.com/platform/bionic/+/master/libc/kernel/
 * for more information.
 */
#ifndef __ASM_PARAM_H
#define __ASM_PARAM_H
#define EXEC_PAGESIZE 65536
#include <asm-generic/param.h>
#endif
