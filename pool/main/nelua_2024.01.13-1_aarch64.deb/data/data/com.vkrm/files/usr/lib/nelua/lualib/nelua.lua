#!/data/data/com.vkrm/files/usr/bin/env lua

-- Run the Nelua compiler.
os.exit(require'nelua.runner'.run(arg))
