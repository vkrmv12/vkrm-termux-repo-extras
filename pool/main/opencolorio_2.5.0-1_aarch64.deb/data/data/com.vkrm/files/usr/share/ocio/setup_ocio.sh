#!/data/data/com.vkrm/files/usr/bin/sh
# SPDX-License-Identifier: BSD-3-Clause
# Copyright Contributors to the OpenColorIO Project.

# For OS X
export DYLD_LIBRARY_PATH="/data/data/com.vkrm/files/usr/lib:${DYLD_LIBRARY_PATH}"

# For Linux
export LD_LIBRARY_PATH="/data/data/com.vkrm/files/usr/lib:${LD_LIBRARY_PATH}"

export PATH="/data/data/com.vkrm/files/usr/bin:${PATH}"
export PYTHONPATH="/data/data/com.vkrm/files/usr/:${PYTHONPATH}"
