#ifndef TOML11_LOCATION_HPP
#define TOML11_LOCATION_HPP

#include "fwd/location_fwd.hpp" // IWYU pragma: export

#if ! defined(TOML11_COMPILE_SOURCES)
#include "impl/location_impl.hpp" // IWYU pragma: export
#endif

#endif // TOML11_LOCATION_HPP
