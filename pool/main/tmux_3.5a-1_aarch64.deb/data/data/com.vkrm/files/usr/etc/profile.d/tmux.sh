export TMUX_TMPDIR=/data/data/com.vkrm/files/usr/var/run
