#!/data/data/com.vkrm/files/usr/bin/sh
export HISTFILE=$SHELL
