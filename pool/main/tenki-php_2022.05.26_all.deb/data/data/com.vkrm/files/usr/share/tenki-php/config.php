<?php
// Title
$title = "Tenki";
// Theme (light dark, sepia)
$theme = "dark";
// Number of entries to display
$inum = 7;
//Enable password protection
$protect = true;
// Password
$password = 'monkey';
// Timezone
$tz = 'Europe/Berlin';
// Footer
$footer = "I really 🧡 <a href='https://www.paypal.com/paypalme/dmpop'>coffee</a>";
// Openweathermap API key
$api_key = "ee3752672ae1423b9bb92919e2b51e97";
?>
