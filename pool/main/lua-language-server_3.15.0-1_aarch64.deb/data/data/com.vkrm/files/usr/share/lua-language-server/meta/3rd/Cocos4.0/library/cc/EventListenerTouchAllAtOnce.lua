---@meta

---@class cc.EventListenerTouchAllAtOnce :cc.EventListener
local EventListenerTouchAllAtOnce = {}
cc.EventListenerTouchAllAtOnce = EventListenerTouchAllAtOnce

---*
---@return boolean
function EventListenerTouchAllAtOnce:init() end
---* / Overrides
---@return self
function EventListenerTouchAllAtOnce:clone() end
---*
---@return boolean
function EventListenerTouchAllAtOnce:checkAvailable() end
---*
---@return self
function EventListenerTouchAllAtOnce:EventListenerTouchAllAtOnce() end
