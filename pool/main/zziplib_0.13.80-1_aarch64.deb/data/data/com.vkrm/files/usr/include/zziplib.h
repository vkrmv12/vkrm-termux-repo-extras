#ifndef ZZIP_WARNING
#define ZZIP_WARNING 1
#ifdef __GNUC__
#warning do no not use <zziplib.h>, update to include <zzip/zzip.h>
#else
#error   do no not use <zziplib.h>, update to include <zzip/zzip.h>
#endif
#endif
#include "zzip/zzip.h"
